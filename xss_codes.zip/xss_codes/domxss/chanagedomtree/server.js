'use strict'

const express = require("express");
const fs = require("fs");

const app     = express();


// Handles the sending of the index
app.get("/dompage", function(req, res){
	
	res.sendFile(__dirname + "/domattack.html");	
		
});


app.listen(3000);
