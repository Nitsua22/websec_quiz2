'use strict'

// The XSS-filters module
const xssFilters = require('xss-filters');

// The express framework
const express = require('express');

// The app
const app = express();

// Needed to parse the request body
const bodyParser = require("body-parser");


// Needed to parse the request body
//Note that in version 4 of express, express.bodyParser() was
//deprecated in favor of a separate 'body-parser' module.
app.use(bodyParser.urlencoded({ extended: true }));

//----------------------------------------------
// A submission of data that on output will
// pass through xss-filters and and will be 
// escaped as to satisfy rule 1
// @param /securesubmit - the endpoint
// @param req - the request
// @param res - the response
// ---------------------------------------------
app.post("/securesubmit", function(req, res){
	
	console.log("Escaped data: " +  xssFilters.inHTMLData(req.body.str));  
	
	// Send back the escaped string
	res.send("This is your input enclosed in the b tags: <b>" + xssFilters.inHTMLData(req.body.str) + "<b>");
	
}); 


//-------------------------------------------------
// A submission of data that will not be sanitized
// on output 
// @param /securesubmit - the endpoint
// @param req - the request
// @param res - the response
// ------------------------------------------------
app.post("/unsecuresubmit", function(req, res){

	// Send back the escaped string
	res.send("This is your input enclosed in the b tags: <b>" + req.body.str+ "<b>");
	
}); 


//-------------------------------------------------
// Serves the homepage
// @param req - the request
// @param res - the response
// ------------------------------------------------
app.get("/", function(req, res){

	// Send back the escaped string
	res.sendFile(__dirname + "/formpage.html");
	
});

app.listen(3000); 
